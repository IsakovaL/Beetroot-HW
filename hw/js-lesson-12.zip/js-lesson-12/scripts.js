
//   $(document).ready(function(){
//     $('.multiple-items').slick();
//     infinite: true;

//     slidesToShow: 4;
  
//     slidesToScroll: 4;
//   });

//Указываем что будем выводить по 3 слайда на экран

// $('.multiple-items').slick({

//   infinite: true,

//   slidesToShow: 4,

//   slidesToScroll: 4

// });
$(document).ready(function(){
    $('.multiple-items').slick({
        infinite: true,

        slidesToShow: 4,
      
        slidesToScroll: 4,
    });
  });